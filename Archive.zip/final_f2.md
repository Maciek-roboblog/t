OK, to zlepmy to wszystko w jeden **spójny, finalny pakiet**:
– obrazy na **Debian 12 + Python 3.11.2**,
– **Argo Workflow** do E2E pipeline’u,
– **Deployment** inferencji na vLLM,
– spójny opis i diagram.

---

# 0. Założenia wspólne

Przyjmijmy:

* Bazowy OS: **Debian 12**
* Python: **3.11.2** (w Debianie 12 pakiet `python3.11` jest 3.11.2 → OK z PyTorch/Transformers/LLaMA‑Factory).
* GPU: nody K8s z **NVIDIA + nvidia‑container‑toolkit** (GPU widoczne jako `nvidia.com/gpu`).
* Registry: np. `eu.gcr.io/<PROJECT>` / Artifact Registry.
* Repo modeli:

  * bazowe: HF **przez Artifactory** (proxy) albo bezpośrednio,
  * wytrenowane: Artifactory / GCS.
* Narzędzia: **LLaMA‑Factory**, **vLLM**, **Argo Workflows**, (opcjonalnie MLflow).

---

# 1. Obrazy Docker – Debian 12 + Python 3.11.2

## 1.1. Obraz treningowy – `llama-factory-train`

**Plik: `Dockerfile.train`**

```dockerfile
FROM debian:12

ENV DEBIAN_FRONTEND=noninteractive

# 1) System + Python 3.11.2 + narzędzia buildowe
RUN apt-get update && apt-get install -y \
    python3.11 python3.11-venv python3-pip \
    build-essential git curl wget ca-certificates \
    && apt-get clean && rm -rf /var/lib/apt/lists/*

# Linki, żeby "python" i "pip" były jednoznaczne
RUN ln -sf /usr/bin/python3.11 /usr/bin/python && \
    ln -sf /usr/bin/pip3 /usr/bin/pip

# 2) Zależności Python – CUDA przez koła PyTorch (cu118)
#    Wymaga sterowników NVIDIA na hoście (nvidia-container-toolkit).
RUN pip install --no-cache-dir --upgrade pip && \
    pip install --no-cache-dir \
      "torch==2.2.0" "torchvision==0.17.0" "torchaudio==2.2.0" \
      --extra-index-url https://download.pytorch.org/whl/cu118 && \
    pip install --no-cache-dir \
      "transformers==4.37.0" "datasets==2.17.0"

# 3) LLaMA-Factory (+ extras do trenowania)
RUN pip install --no-cache-dir "llamafactory[torch,metrics]==0.9.3"

# (opcjonalnie)
# RUN pip install --no-cache-dir "bitsandbytes==0.43.0" "deepspeed==0.14.0"

WORKDIR /app

# Zakładamy, że configi będą montowane z ConfigMap / PV
# Domyślnie wchodzimy w bash; Argo/K8s poda konkretną komendę
ENTRYPOINT ["/bin/bash"]
```

> ✔ Debian 12, ✔ Python 3.11.2, ✔ PyTorch z CUDA, ✔ Transformers, ✔ LLaMA‑Factory.

---

## 1.2. Obraz inferencyjny – `llama-factory-api` (vLLM)

**Plik: `Dockerfile.api`**

```dockerfile
FROM debian:12

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update && apt-get install -y \
    python3.11 python3-pip \
    build-essential git curl ca-certificates \
    && apt-get clean && rm -rf /var/lib/apt/lists/*

RUN ln -sf /usr/bin/python3.11 /usr/bin/python && \
    ln -sf /usr/bin/pip3 /usr/bin/pip

# PyTorch z CUDA + Transformers + vLLM + LLaMA-Factory
RUN pip install --no-cache-dir --upgrade pip && \
    pip install --no-cache-dir \
      "torch==2.2.0" "torchvision==0.17.0" \
      --extra-index-url https://download.pytorch.org/whl/cu118 && \
    pip install --no-cache-dir \
      "transformers==4.37.0" \
      "vllm==0.4.0" \
      "llamafactory[torch]==0.9.3"

WORKDIR /app

# Konfiguracja inferencji będzie montowana jako plik
# /app/config/inference.yaml
EXPOSE 8000

CMD ["llamafactory-cli", "api", "/app/config/inference.yaml", "infer_backend=vllm", "API_PORT=8000"]
```

> Ten obraz służy wyłącznie do inferencji (OpenAI‑style API na vLLM).

---

# 2. Kubernetes: namespace, Secret, PVC

## 2.1. Namespace’y

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: llm-training
---
apiVersion: v1
kind: Namespace
metadata:
  name: llm-inference
---
apiVersion: v1
kind: Namespace
metadata:
  name: llm-argo
```

## 2.2. Sekrety (HF token + Artifactory)

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: hf-secret
  namespace: llm-training
type: Opaque
stringData:
  HF_TOKEN: "hf_xxxxx"

---
apiVersion: v1
kind: Secret
metadata:
  name: artifactory-secret
  namespace: llm-training
type: Opaque
stringData:
  ARTIFACTORY_URL: "https://artifactory.example.com/hf-proxy"
  ARTIFACTORY_USER: "user"
  ARTIFACTORY_PASSWORD: "pass"
```

Pod inference możesz użyć tych samych sekretów (zduplikować w `llm-inference` albo użyć Secretów w innym namespace przez narzędzia typu ExternalSecrets).

## 2.3. PVC na model

Minimalny przykład – 50Gi na wytrenowane modele:

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: model-output-pvc
  namespace: llm-training
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 50Gi
  storageClassName: standard   # lub własny SC

---
# Ten sam PVC używany w inference (zakładamy ten sam SC i dostęp do storage)
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: model-output-pvc
  namespace: llm-inference
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 50Gi
  storageClassName: standard
```

W praktyce możesz mieć jeden PV ze wsparciem `ReadWriteMany` (NFS/CSI) i używać go równolegle.

---

# 3. Argo Workflow – E2E pipeline (pre‑download → train → deploy)

Załóżmy, że:

* Argo Workflows jest zainstalowane w `llm-argo`,
* workflow będzie działał w namespace **`llm-training`**,
* **Krok 1:** (opcjonalnie) pobieramy model bazowy z Artifactory na PV,
* **Krok 2:** trenujemy LLaMA‑Factory,
* **Krok 3:** tworzymy/aktualizujemy Deployment inferencyjny w namespace `llm-inference`.

## 3.1. ConfigMap z configiem treningowym

**(prostota – w realu pewnie trzymasz YAML w repo Git i montujesz inaczej)**

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: llama-train-config
  namespace: llm-training
data:
  train_config.yaml: |
    model_name_or_path: /models/base-model       # tu krok 1 wrzuca model bazowy
    stage: sft
    finetuning_type: lora
    dataset: my_corp_dataset
    template: llama3
    output_dir: /output/ft-llama3-8b-v1
    per_device_train_batch_size: 1
    num_train_epochs: 3
    learning_rate: 1e-4
```

## 3.2. Argo Workflow

**Plik: `workflow-llama-factory.yaml`**

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Workflow
metadata:
  generateName: llama-ft-
  namespace: llm-argo
spec:
  entrypoint: fine-tune-and-deploy
  serviceAccountName: argo-workflow-sa   # musi mieć uprawnienia do llm-training i llm-inference

  arguments:
    parameters:
      - name: base-model-url
        value: "https://artifactory.example.com/hf-proxy/meta-llama/Meta-Llama-3-8B"
      - name: target-model-name
        value: "meta-llama3-8b-ft-v1"

  templates:
  - name: fine-tune-and-deploy
    steps:
      - - name: download-base-model
          template: download-base-model
      - - name: train-model
          template: train-model
      - - name: deploy-inference
          template: deploy-inference

  # Krok 1: pobranie modelu bazowego na PV
  - name: download-base-model
    inputs:
      parameters:
        - name: base-model-url
    container:
      image: curlimages/curl:8.6.0
      command: ["/bin/sh", "-c"]
      args:
        - |
          echo "Downloading base model from Artifactory: {{inputs.parameters.base-model-url}}";
          mkdir -p /models/base-model;
          curl -u $ARTIFACTORY_USER:$ARTIFACTORY_PASSWORD -L \
               "{{inputs.parameters.base-model-url}}/model.bin" -o /models/base-model/pytorch_model.bin;
          curl -u $ARTIFACTORY_USER:$ARTIFACTORY_PASSWORD -L \
               "{{inputs.parameters.base-model-url}}/config.json" -o /models/base-model/config.json;
          curl -u $ARTIFACTORY_USER:$ARTIFACTORY_PASSWORD -L \
               "{{inputs.parameters.base-model-url}}/tokenizer.json" -o /models/base-model/tokenizer.json;
      env:
        - name: ARTIFACTORY_USER
          valueFrom:
            secretKeyRef:
              name: artifactory-secret
              key: ARTIFACTORY_USER
        - name: ARTIFACTORY_PASSWORD
          valueFrom:
            secretKeyRef:
              name: artifactory-secret
              key: ARTIFACTORY_PASSWORD
      volumeMounts:
        - name: model-storage
          mountPath: /models
    volumes:
      - name: model-storage
        persistentVolumeClaim:
          claimName: model-output-pvc
    # Krok działa w llm-training:
    metadata:
      namespace: llm-training

  # Krok 2: trening LLaMA-Factory
  - name: train-model
    container:
      image: my-registry/llama-factory-train:latest
      command: ["/bin/bash", "-c"]
      args:
        - |
          echo "Starting fine-tune...";
          cp /config/train_config.yaml /app/train_config.yaml;
          HF_ENDPOINT="$HF_ENDPOINT" HF_TOKEN="$HF_TOKEN" \
          llamafactory-cli train /app/train_config.yaml;
          echo "Fine-tune finished.";
      env:
        - name: HF_TOKEN
          valueFrom:
            secretKeyRef:
              name: hf-secret
              key: HF_TOKEN
        # Jeśli używasz HF proxy przez Artifactory:
        - name: HF_ENDPOINT
          valueFrom:
            secretKeyRef:
              name: artifactory-secret
              key: ARTIFACTORY_URL
      volumeMounts:
        - name: model-storage
          mountPath: /models
        - name: output-storage
          mountPath: /output
        - name: train-config
          mountPath: /config
      resources:
        limits:
          nvidia.com/gpu: 1
        requests:
          nvidia.com/gpu: 1
    volumes:
      - name: model-storage
        persistentVolumeClaim:
          claimName: model-output-pvc
      - name: output-storage
        persistentVolumeClaim:
          claimName: model-output-pvc
      - name: train-config
        configMap:
          name: llama-train-config
    metadata:
      namespace: llm-training

  # Krok 3: Deployment inferencji w namespace llm-inference
  - name: deploy-inference
    inputs:
      parameters:
        - name: target-model-name
    resource:
      action: apply
      manifest: |
        apiVersion: apps/v1
        kind: Deployment
        metadata:
          name: llama-factory-inference
          namespace: llm-inference
          labels:
            app: llama-infer
        spec:
          replicas: 1
          selector:
            matchLabels:
              app: llama-infer
          template:
            metadata:
              labels:
                app: llama-infer
            spec:
              containers:
              - name: inference
                image: my-registry/llama-factory-api:latest
                imagePullPolicy: IfNotPresent
                ports:
                  - containerPort: 8000
                env:
                  - name: HF_TOKEN
                    valueFrom:
                      secretKeyRef:
                        name: hf-secret
                        key: HF_TOKEN
                  - name: MODEL_PATH
                    value: "/models/ft-llama3-8b-v1"
                resources:
                  limits:
                    nvidia.com/gpu: 1
                  requests:
                    nvidia.com/gpu: 1
                volumeMounts:
                  - name: model-storage
                    mountPath: /models
              volumes:
                - name: model-storage
                  persistentVolumeClaim:
                    claimName: model-output-pvc
```

> Ten workflow:
> 1️⃣ pobiera model bazowy → `/models/base-model`,
> 2️⃣ trenuje i zapisuje fine‑tuned model do `/output/ft-llama3-8b-v1` (czyli w PV),
> 3️⃣ stawia Deployment API w namespace `llm-inference`, który montuje ten sam PV i używa ścieżki `/models/ft-llama3-8b-v1`.

---

# 4. Deployment + Service + HPA (inference) – jako osobne YAML

Jeśli chcesz mieć Deployment niezależnie od Argo (np. do ręcznego odpalenia):

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: llama-factory-inference
  namespace: llm-inference
spec:
  replicas: 1
  selector:
    matchLabels:
      app: llama-infer
  template:
    metadata:
      labels:
        app: llama-infer
    spec:
      containers:
        - name: inference
          image: my-registry/llama-factory-api:latest
          ports:
            - containerPort: 8000
          env:
            - name: HF_TOKEN
              valueFrom:
                secretKeyRef:
                  name: hf-secret
                  key: HF_TOKEN
            - name: MODEL_PATH
              value: "/models/ft-llama3-8b-v1"
          resources:
            limits:
              nvidia.com/gpu: 1
            requests:
              nvidia.com/gpu: 1
          volumeMounts:
            - name: model-storage
              mountPath: /models
      volumes:
        - name: model-storage
          persistentVolumeClaim:
            claimName: model-output-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: llama-factory-inference
  namespace: llm-inference
spec:
  type: ClusterIP
  selector:
    app: llama-infer
  ports:
    - port: 8000
      targetPort: 8000
      name: http
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: llama-inference-hpa
  namespace: llm-inference
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: llama-factory-inference
  minReplicas: 1
  maxReplicas: 4
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 60
```

> HPA jest tu na CPU (najprościej). W produkcji można iść w custom metrics (np. latency/qps z Prometheusa).

---

# 5. High‑level architektura – Mermaid

```mermaid
flowchart LR
    DS[Data Scientist]:::actor
    APP[Klient / Aplikacja]:::actor

    subgraph CTRL[Control Plane (GitOps/MLOps)]
      Git[(Git repo\nYAML/Helm/Configi)]
      ArgoCD[Argo CD]
      ModelReg[(Model Registry / Artifactory/GCS)]
    end

    subgraph TRAIN[Training (ns: llm-training)]
      ArgoWF[Argo Workflows]
      TrainJob[Pods: LLaMA-Factory\nFine-tuning (GPU)]
      PVC[(PV/PVC\nmodel-output-pvc)]
      HF[(HF Hub lub HF przez Artifactory)]
    end

    subgraph INF[Inference (ns: llm-inference)]
      APIGW[Ingress/API Gateway]
      VLLM[Deployment: llama-factory-api\n(vLLM, GPU)]
    end

    classDef actor fill=#fff,stroke=#333,stroke-width=1;

    DS --> Git
    DS --> ArgoWF

    ArgoCD --> TRAIN
    ArgoCD --> INF

    ArgoWF --> TrainJob
    TrainJob --> HF
    TrainJob --> PVC
    TrainJob --> ModelReg

    VLLM --> PVC
    VLLM --> ModelReg

    APP --> APIGW
    APIGW --> VLLM
```

---

# 6. Jak tego używać w praktyce (skrót)

1. **Zbuduj obrazy** (lokalnie lub przez Cloud Build):

   ```bash
   docker build -f Dockerfile.train -t my-registry/llama-factory-train:latest .
   docker build -f Dockerfile.api   -t my-registry/llama-factory-api:latest .
   docker push my-registry/llama-factory-train:latest
   docker push my-registry/llama-factory-api:latest
   ```

2. **Na klastrze K8s**:

   * utwórz namespace’y (`llm-training`, `llm-inference`, `llm-argo`),
   * utwórz Secrets (`hf-secret`, `artifactory-secret`),
   * utwórz PVC (`model-output-pvc`).

3. **Zainstaluj Argo Workflows** (w `llm-argo`) i ewentualnie Argo CD.

4. **Zaaplikuj ConfigMap i Workflow**:

   ```bash
   kubectl apply -f train-config-cm.yaml
   kubectl apply -f workflow-llama-factory.yaml
   ```

5. **Start pipeline’u**:

   * przez Argo UI lub:

     ```bash
     argo submit -n llm-argo workflow-llama-factory.yaml \
       -p base-model-url="https://artifactory.example.com/..." \
       -p target-model-name="meta-llama3-8b-ft-v1" \
       --watch
     ```

6. Po skończonym pipeline:

   * Deployment `llama-factory-inference` stoi w `llm-inference`,
   * możesz wystawić go przez Ingress/API GW i używać jak OpenAI API.

---

To jest **spójna, finalna wersja**:

* baza: **Debian 12 + Python 3.11.2**,
* osobne obrazy: trening + inferencja (vLLM),
* pełny pipeline w **Argo**,
* integracja z **Artifactory/HF**,
* dynamiczne ładowanie modeli przez PVC/GCS/Artifactory,
* i opis architektury na poziomie infrastruktury.
